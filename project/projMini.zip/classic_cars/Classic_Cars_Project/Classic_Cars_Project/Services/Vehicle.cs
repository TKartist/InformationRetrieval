﻿using System;
namespace Classic_Cars_Project.Services
{
    public class Vehicle
    {
        public string image_url { get; set; }
        public string Brand { get; set; }
        public string model { get; set; }
        public int Price { get; set; }
        public string Year { get; set; }
        public string text { get; set; }
        public string detail_url{ get; set; }

    }

}
