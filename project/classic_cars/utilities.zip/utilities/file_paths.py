json_files = [
    "../JSONS/contents_ccc.json",
    "../JSONS/contents_erc.json",
    "../JSONS/contents_ccs.json",
]
DBPATH = "../JSONS/jsonDB.json"
INDEXPATH = "../JSONS/indexJson.json"
